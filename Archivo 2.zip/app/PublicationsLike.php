<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PublicationsLike extends Model
{
    //
}
