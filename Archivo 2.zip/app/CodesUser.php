<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CodesUser extends Model
{
    //
}
