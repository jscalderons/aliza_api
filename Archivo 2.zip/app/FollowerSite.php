<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FollowerSite extends Model
{
    //
}
